echo "Heuristic, Board, Score, Path Length, Nodes Expanded, Branching Factor"
python3 astar.py grid10.txt 1 -c
python3 astar.py grid10.txt 2 -c
python3 astar.py grid10.txt 3 -c
python3 astar.py grid10.txt 4 -c
python3 astar.py grid10.txt 5 -c
python3 astar.py grid10.txt 6 -c

python3 astar.py grid20.txt 1 -c
python3 astar.py grid20.txt 2 -c
python3 astar.py grid20.txt 3 -c
python3 astar.py grid20.txt 4 -c
python3 astar.py grid20.txt 5 -c
python3 astar.py grid20.txt 6 -c

python3 astar.py grid25.txt 1 -c
python3 astar.py grid25.txt 2 -c
python3 astar.py grid25.txt 3 -c
python3 astar.py grid25.txt 4 -c
python3 astar.py grid25.txt 5 -c
python3 astar.py grid25.txt 6 -c

python3 astar.py grid35.txt 1 -c
python3 astar.py grid35.txt 2 -c
python3 astar.py grid35.txt 3 -c
python3 astar.py grid35.txt 4 -c
python3 astar.py grid35.txt 5 -c
python3 astar.py grid35.txt 6 -c

python3 astar.py grid50.txt 1 -c
python3 astar.py grid50.txt 2 -c
python3 astar.py grid50.txt 3 -c
python3 astar.py grid50.txt 4 -c
python3 astar.py grid50.txt 5 -c
python3 astar.py grid50.txt 6 -c
